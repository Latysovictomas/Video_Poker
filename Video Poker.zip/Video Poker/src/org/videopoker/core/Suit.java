package org.videopoker.core;

public enum Suit {
	Diamonds, Spades, Hearts, Clubs;
}
